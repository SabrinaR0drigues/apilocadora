﻿namespace ApiLocadora
{
    public class filme
    {

        public string Nome { get; set; }
        public string Genero { get; set; }
    }
}
