﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiLocadora.Controllers
{
    [Route("filmes")]
    [ApiController]
    public class FilmeController : ControllerBase
    {


        [HttpGet]

        public IActionResult  BuscaFilmes() 
        
        {

            List  <filme > filmes = new List<filme> ();

            filmes.Add(new filme
            {
                Nome = "Fast And Furious",
                Genero = "action"

            });
            
            filmes.Add(new filme
            {
                Nome = "Call Me By Your Name",
                Genero = "Drama/Romance"

            })
                
                ;filmes.Add(new filme
            {
                Nome = "Aftersun",
                Genero = "Drama"

            });
            
            return Ok(filmes);
        
        }


     }
}
